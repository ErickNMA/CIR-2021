//
// Created by Miguel on 08/04/2021.
// Modified by Erick on 07/02/2022.
//

#include <ode/ode.h>
#include <plugins/physics.h>
#include <string.h>
#include <stdio.h>

static pthread_mutex_t mutex;

/*Geoms used in the plugin*/

static dGeomID yellow_robot_geom;
static dGeomID blue_robot_geom;

static dGeomID brw_geom;
static dGeomID blw_geom;
static dGeomID yrw_geom;
static dGeomID ylw_geom;

static dGeomID lab_geom;
static dGeomID moving_center_geom;
static dGeomID moving_block_geom;

void webots_physics_init() {
    pthread_mutex_init(&mutex, NULL);

    yellow_robot_geom = dWebotsGetGeomFromDEF("Amarelo");
    blue_robot_geom = dWebotsGetGeomFromDEF("Azul");

    brw_geom = dWebotsGetGeomFromDEF("brw");
    blw_geom = dWebotsGetGeomFromDEF("blw");
    yrw_geom = dWebotsGetGeomFromDEF("yrw");
    ylw_geom = dWebotsGetGeomFromDEF("ylw");

    lab_geom = dWebotsGetGeomFromDEF("Labirinto");
    moving_center_geom = dWebotsGetGeomFromDEF("center");
    moving_block_geom = dWebotsGetGeomFromDEF("Moving_Block");
}

void webots_physics_step() {
}

int isBlueCollision(dGeomID g1, dGeomID g2) {
    int a = ((dAreGeomsSame(g1, lab_geom) && dAreGeomsSame(g2, blue_robot_geom)) || (dAreGeomsSame(g2, lab_geom) && dAreGeomsSame(g1, blue_robot_geom)));            
    int b = ((dAreGeomsSame(g1, moving_center_geom) && dAreGeomsSame(g2, blue_robot_geom)) || (dAreGeomsSame(g2, moving_center_geom) && dAreGeomsSame(g1, blue_robot_geom)));
    int c = ((dAreGeomsSame(g1, moving_block_geom) && dAreGeomsSame(g2, blue_robot_geom)) || (dAreGeomsSame(g2, moving_block_geom) && dAreGeomsSame(g1, blue_robot_geom)));
    
    int d = ((dAreGeomsSame(g1, lab_geom) && dAreGeomsSame(g2, brw_geom)) || (dAreGeomsSame(g2, lab_geom) && dAreGeomsSame(g1, brw_geom)));            
    int e = ((dAreGeomsSame(g1, moving_center_geom) && dAreGeomsSame(g2, brw_geom)) || (dAreGeomsSame(g2, moving_center_geom) && dAreGeomsSame(g1, brw_geom)));
    int f = ((dAreGeomsSame(g1, moving_block_geom) && dAreGeomsSame(g2, brw_geom)) || (dAreGeomsSame(g2, moving_block_geom) && dAreGeomsSame(g1, brw_geom)));

    int g = ((dAreGeomsSame(g1, lab_geom) && dAreGeomsSame(g2, blw_geom)) || (dAreGeomsSame(g2, lab_geom) && dAreGeomsSame(g1, blw_geom)));            
    int h = ((dAreGeomsSame(g1, moving_center_geom) && dAreGeomsSame(g2, blw_geom)) || (dAreGeomsSame(g2, moving_center_geom) && dAreGeomsSame(g1, blw_geom)));
    int i = ((dAreGeomsSame(g1, moving_block_geom) && dAreGeomsSame(g2, blw_geom)) || (dAreGeomsSame(g2, moving_block_geom) && dAreGeomsSame(g1, blw_geom)));
    
    return a || b || c || d || e || f || g || h || i;
}

int isYellowCollision(dGeomID g1, dGeomID g2) {
    int a = ((dAreGeomsSame(g1, lab_geom) && dAreGeomsSame(g2, yellow_robot_geom)) || (dAreGeomsSame(g2, lab_geom) && dAreGeomsSame(g1, yellow_robot_geom)));            
    int b = ((dAreGeomsSame(g1, moving_center_geom) && dAreGeomsSame(g2, yellow_robot_geom)) || (dAreGeomsSame(g2, moving_center_geom) && dAreGeomsSame(g1, yellow_robot_geom)));
    int c = ((dAreGeomsSame(g1, moving_block_geom) && dAreGeomsSame(g2, yellow_robot_geom)) || (dAreGeomsSame(g2, moving_block_geom) && dAreGeomsSame(g1, yellow_robot_geom)));

    int d = ((dAreGeomsSame(g1, lab_geom) && dAreGeomsSame(g2, yrw_geom)) || (dAreGeomsSame(g2, lab_geom) && dAreGeomsSame(g1, yrw_geom)));            
    int e = ((dAreGeomsSame(g1, moving_center_geom) && dAreGeomsSame(g2, yrw_geom)) || (dAreGeomsSame(g2, moving_center_geom) && dAreGeomsSame(g1, yrw_geom)));
    int f = ((dAreGeomsSame(g1, moving_block_geom) && dAreGeomsSame(g2, yrw_geom)) || (dAreGeomsSame(g2, moving_block_geom) && dAreGeomsSame(g1, yrw_geom)));

    int g = ((dAreGeomsSame(g1, lab_geom) && dAreGeomsSame(g2, ylw_geom)) || (dAreGeomsSame(g2, lab_geom) && dAreGeomsSame(g1, ylw_geom)));            
    int h = ((dAreGeomsSame(g1, moving_center_geom) && dAreGeomsSame(g2, ylw_geom)) || (dAreGeomsSame(g2, moving_center_geom) && dAreGeomsSame(g1, ylw_geom)));
    int i = ((dAreGeomsSame(g1, moving_block_geom) && dAreGeomsSame(g2, ylw_geom)) || (dAreGeomsSame(g2, moving_block_geom) && dAreGeomsSame(g1, ylw_geom)));

    return a || b || c || d || e || f || g || h || i;
}

int isRobotCollision(dGeomID g1, dGeomID g2) {
    int a = ((dAreGeomsSame(g1, yellow_robot_geom) && dAreGeomsSame(g2, blue_robot_geom)) || (dAreGeomsSame(g2, yellow_robot_geom) && dAreGeomsSame(g1, blue_robot_geom)));
    int b = ((dAreGeomsSame(g1, yellow_robot_geom) && dAreGeomsSame(g2, brw_geom)) || (dAreGeomsSame(g2, yellow_robot_geom) && dAreGeomsSame(g1, brw_geom)));
    int c = ((dAreGeomsSame(g1, yellow_robot_geom) && dAreGeomsSame(g2, blw_geom)) || (dAreGeomsSame(g2, yellow_robot_geom) && dAreGeomsSame(g1, blw_geom)));
    int d = ((dAreGeomsSame(g1, yrw_geom) && dAreGeomsSame(g2, blue_robot_geom)) || (dAreGeomsSame(g2, yrw_geom) && dAreGeomsSame(g1, blue_robot_geom)));
    int e = ((dAreGeomsSame(g1, ylw_geom) && dAreGeomsSame(g2, blue_robot_geom)) || (dAreGeomsSame(g2, ylw_geom) && dAreGeomsSame(g1, blue_robot_geom)));
    int f = ((dAreGeomsSame(g1, yrw_geom) && dAreGeomsSame(g2, brw_geom)) || (dAreGeomsSame(g2, yrw_geom) && dAreGeomsSame(g1, brw_geom)));
    int g = ((dAreGeomsSame(g1, yrw_geom) && dAreGeomsSame(g2, blw_geom)) || (dAreGeomsSame(g2, yrw_geom) && dAreGeomsSame(g1, blw_geom)));
    
    return a || b || c || d || e || f || g;
}

int webots_physics_collide(dGeomID g1, dGeomID g2) 
{
    dContact contact;
    double pos1[3], pos2[3], pos3[3];
    int cont=0;
    
    for(int i=0; i<3; i++)
    {
        pos1[i] = 20;
        pos2[i] = 20;
        pos3[i] = 20;
    }

    if (isBlueCollision(g1, g2)) 
    {
        if (dCollide(g1, g2, 10, &contact.geom, sizeof(dContact))) 
        {
            pos1[0] = contact.geom.pos[0];
            pos1[1] = contact.geom.pos[1];
            pos1[2] = contact.geom.pos[2];
        }
        cont++;      
    }

    if (isYellowCollision(g1, g2)) 
    {
        if (dCollide(g1, g2, 10, &contact.geom, sizeof(dContact))) 
        {
            pos2[0] = contact.geom.pos[0];
            pos2[1] = contact.geom.pos[1];
            pos2[2] = contact.geom.pos[2];       
        }
        cont++; 
    }

    if (isRobotCollision(g1, g2)) 
    {
        if (dCollide(g1, g2, 10, &contact.geom, sizeof(dContact))) 
        {
            pos3[0] = contact.geom.pos[0];
            pos3[1] = contact.geom.pos[1];
            pos3[2] = contact.geom.pos[2];
        }
        cont++; 
    }

    if(cont)
    {
        dWebotsSend(2, pos1, sizeof(pos1));
        dWebotsSend(2, pos2, sizeof(pos2));
        dWebotsSend(2, pos3, sizeof(pos3));
        return 2;
    }else
    {
        return 0;
    }
}

void webots_physics_cleanup() {
    pthread_mutex_destroy(&mutex);
}

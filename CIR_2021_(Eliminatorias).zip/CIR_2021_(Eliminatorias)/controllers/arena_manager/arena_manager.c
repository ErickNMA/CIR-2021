//
// Created by Erick on 06/02/2022.
//



#include <webots/supervisor.h>
#include <webots/robot.h>
#include <webots/distance_sensor.h>
#include <webots/motor.h>
#include <webots/position_sensor.h>
#include <webots/brake.h>
#include <webots/receiver.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define TIME_STEP 8

void move(WbNodeRef object, double *p0, double *p, double velocity)
{
    WbFieldRef object_translation = wb_supervisor_node_get_field(object, "translation");
    double pos[3] = {p0[0], p0[1], p0[2]};
    double k = 0.001;

    while (wb_robot_step(TIME_STEP) != -1) 
    {
        if (pos[0] < p[0])
        {
            pos[0] += (k*velocity);
        } else
        {
            pos[0] -= (k*velocity);
        }
        if (pos[2] < p[2])
        {
            pos[2] += (k*velocity);
        } else
        {
            pos[2] -= (k*velocity);
        }

        wb_supervisor_field_set_sf_vec3f(object_translation, pos);

        if((pos[0]-p[0] < k) && (pos[1]-p[1] < k) && (pos[2]-p[2] < k))
        {
          break;           
        }

        if((pos[0]-p[0] < (k*velocity)) && (pos[1]-p[1] < (k*velocity)) && (pos[2]-p[2] < (k*velocity)))
        {
          velocity--;            
        }  
    }        
}

int main()
{
    wb_robot_init();

    WbDeviceTag ds1 = wb_robot_get_device("ds1");
    WbDeviceTag ds2 = wb_robot_get_device("ds2");
    WbDeviceTag center_motor = wb_robot_get_device("center_motor");
    WbDeviceTag bk = wb_robot_get_device("brake");
    wb_motor_set_torque(center_motor, 1000);
    WbDeviceTag center_encoder = wb_robot_get_device("center_encoder");
    wb_position_sensor_enable(center_encoder, TIME_STEP);
    wb_distance_sensor_enable(ds1, TIME_STEP);
    wb_distance_sensor_enable(ds2, TIME_STEP);
    double posin[3] = {0.159, 0, -0.106};
    double posfin[3] = {-0.125, 0, 0.178};    
    WbNodeRef block = wb_supervisor_node_get_from_def("Moving_Block");
    WbNodeRef br_node = wb_supervisor_node_get_from_def("Azul");
    WbNodeRef yr_node = wb_supervisor_node_get_from_def("Amarelo");
    WbNodeRef bp_node = wb_supervisor_node_get_from_def("Blue_Pointer");
    WbNodeRef yp_node = wb_supervisor_node_get_from_def("Yellow_Pointer"); 

    WbFieldRef blue_robot, yellow_robot, blue_pointer, yellow_pointer;
    if(br_node)
    {    
        blue_robot = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Azul"), "translation");
    }
    if(yr_node)
    {
        yellow_robot = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Amarelo"), "translation");
    }
    if(bp_node)
    {
        blue_pointer = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Blue_Pointer"), "translation");
    }
    if(yp_node)
    {
        yellow_pointer = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Yellow_Pointer"), "translation");
    }
    double l1, l2;
    double  *blue_pos, *yellow_pos;
    double alt = 0.4;
    double p0_blue[3] = {5.89, 0.51, -0.55};
    double p0_yellow[3] = {7.28, 0.51, -0.79};
    int controle=1, sign;
    bool check = true;
    int mode=1, large=4, fine;
    double dtime, reference_time, ang_vel, desloc;
    double positions[6] = {0.864, 1.412, 1.957, 4.422, 4.978, 5.534};

    WbNodeRef bcm_ref, ycm_ref, rcm_ref;
    WbFieldRef bcm_tf, ycm_tf, rcm_tf;
    WbDeviceTag data_receiver = wb_robot_get_device("receiver");
    wb_receiver_enable(data_receiver, TIME_STEP);  
    wb_receiver_set_channel(data_receiver, 2);  
    unsigned int current_bcm = 1, current_ycm = 1, current_rcm = 1, max_cm = 25;

    while (wb_robot_step(TIME_STEP) != -1) 
    {        
        while(wb_receiver_get_queue_length(data_receiver) > 0)
        {   
            double *buffer;
                
                double *bcm_pos = malloc(sizeof(double) * 3);
                double *ycm_pos = malloc(sizeof(double) * 3);
                double *rcm_pos = malloc(sizeof(double) * 3);
                
                {   
                        buffer = wb_receiver_get_data(data_receiver);       
                        if((buffer[0] != 20) || (buffer[1] != 20) || (buffer[2] != 20))
                        {
                            bcm_pos[0] = buffer[0];
                            bcm_pos[1] = buffer[1] + .5;
                            bcm_pos[2] = buffer[2];
                
                            char bcm_def[6];
                
                            snprintf(bcm_def, 5, "bcm%d", current_bcm);
                            current_bcm++;
                
                            if (current_bcm == max_cm)
                                current_bcm = 1;
                
                            bcm_ref = wb_supervisor_node_get_from_def(bcm_def);
                            bcm_tf = wb_supervisor_node_get_field(bcm_ref, "translation");
                
                            wb_supervisor_field_set_sf_vec3f(bcm_tf, bcm_pos);
                        }            
                        wb_receiver_next_packet(data_receiver);

                        buffer = wb_receiver_get_data(data_receiver);
                        if((buffer[0] != 20) || (buffer[1] != 20) || (buffer[2] != 20))
                        {                        
                            ycm_pos[0] = buffer[0];
                            ycm_pos[1] = buffer[1] + .5;
                            ycm_pos[2] = buffer[2];
                
                            char ycm_def[6];
                
                            snprintf(ycm_def, 5, "ycm%d", current_ycm);
                            current_ycm++;
                
                            if (current_ycm == max_cm)
                                current_ycm = 1;
                
                            ycm_ref = wb_supervisor_node_get_from_def(ycm_def);
                            ycm_tf = wb_supervisor_node_get_field(ycm_ref, "translation");
                
                            wb_supervisor_field_set_sf_vec3f(ycm_tf, ycm_pos);
                        }            
                        wb_receiver_next_packet(data_receiver);                    
                    
                        buffer = wb_receiver_get_data(data_receiver);
                        if((buffer[0] != 20) || (buffer[1] != 20) || (buffer[2] != 20))
                        { 
                            rcm_pos[0] = buffer[0];
                            rcm_pos[1] = buffer[1] + .5;
                            rcm_pos[2] = buffer[2];
                
                            char rcm_def[6];
                
                            snprintf(rcm_def, 5, "rcm%d", current_rcm);
                            current_rcm++;
                
                            if (current_rcm == max_cm)
                                current_rcm = 1;
                
                            rcm_ref = wb_supervisor_node_get_from_def(rcm_def);
                            rcm_tf = wb_supervisor_node_get_field(rcm_ref, "translation");
                
                            wb_supervisor_field_set_sf_vec3f(rcm_tf, rcm_pos);
                        }            
                        wb_receiver_next_packet(data_receiver);
                }                
                free(bcm_pos);
                free(ycm_pos);
                free(rcm_pos);
        }

        if(check == true)
        {
            l1 = wb_distance_sensor_get_value(ds1);
            l2 = wb_distance_sensor_get_value(ds2);
            if((l1 != 1000) || (l2 != 1000))
            {
                move(block, posin, posfin, 10.0);
                check = false;
            } 
        }
        if(br_node && bp_node) 
        {    
            blue_pos = wb_supervisor_field_get_sf_vec3f(blue_robot);
            blue_pos[1] += alt;
            wb_supervisor_field_set_sf_vec3f(blue_pointer, blue_pos);
        }else
        {
            if(bp_node)
            {
                wb_supervisor_field_set_sf_vec3f(blue_pointer, p0_blue);
                p0_blue[1] += 0.8;
            }            
        }
        if(yr_node && yp_node)
        {
            yellow_pos = wb_supervisor_field_get_sf_vec3f(yellow_robot);
            yellow_pos[1] += alt;
            wb_supervisor_field_set_sf_vec3f(yellow_pointer, yellow_pos);
        }else
        {
            if(yp_node)
            {
                wb_supervisor_field_set_sf_vec3f(yellow_pointer, p0_yellow);
                p0_yellow[1] += 0.8;
            }            
        }
        if(controle == 1)
        {
            alt -= 0.003;
        }else
        {
            alt += 0.003;
        }
        if((controle == 1) && (alt <= 0.2))
        {
            controle = 2;
        }
        if((controle == 2) && (alt >= 0.4))
        {
            controle = 1;
        }

        switch(mode)
        {
            case 1:
                srand(time(NULL));
                dtime = ((rand()%6)+5);
                reference_time = wb_robot_get_time();
                mode++;
            break; 
            case 2:                
                if((wb_robot_get_time()-reference_time) >= dtime)
                {
                    mode++;
                }
            break; 
            case 3:
                srand(time(NULL));
                ang_vel = (((rand()%13)/100.0)+0.08);
                wb_brake_set_damping_constant(bk, 0);
                wb_motor_set_velocity(center_motor, ang_vel);
                wb_motor_set_acceleration(center_motor, 0.1);
                srand(time(NULL));
                sign = (rand()%2);
                if(sign)
                {
                    desloc = positions[large];
                }else
                {
                    desloc = (positions[large]-(2*M_PI));
                }
                wb_motor_set_position(center_motor, desloc);                
                mode++;                
            break;
            case 4:
                if(fabs(wb_position_sensor_get_value(center_encoder) - desloc) < 0.01)
                {
                    wb_brake_set_damping_constant(bk, 5000000);
                    if(sign)
                    {
                        fine = large+1;
                    }else
                    {
                        fine = large-1;
                    }
                    srand(time(NULL));
                    dtime = ((rand()%6)+5);
                    reference_time = wb_robot_get_time();                    
                    mode++;
                }
            break;
            case 5:
                if((wb_robot_get_time()-reference_time) >= dtime)
                {
                    wb_brake_set_damping_constant(bk, 0);
                    wb_motor_set_velocity(center_motor, ang_vel);
                    wb_motor_set_acceleration(center_motor, 0.1);
                    if(sign)
                    {
                        desloc = positions[fine];
                    }else
                    {
                        desloc = (positions[fine]-(2*M_PI));
                    }
                    wb_motor_set_position(center_motor, desloc);
                    mode++;
                } 
            break;
            case 6:
                if(fabs(wb_position_sensor_get_value(center_encoder) - desloc) < 0.01)
                {
                    wb_brake_set_damping_constant(bk, 5000000);
                    if(large == 4)
                    {
                        large = 1;
                    }else
                    {
                        large = 4;
                    }
                    mode = 1;
                }
            break;                              
        }  
    }

    wb_robot_cleanup();

    return 0;
}
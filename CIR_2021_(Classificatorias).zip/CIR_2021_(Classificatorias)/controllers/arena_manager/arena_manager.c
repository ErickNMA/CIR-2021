#include <webots/supervisor.h>
#include <webots/robot.h>
#include <webots/distance_sensor.h>
#include <stdio.h>

#define TIME_STEP 8

//WbNodeRef wb_supervisor_node_get_from_device("");

//void wb_supervisor_field_enable_sf_tracking(WbFieldRef field, int sampling_period);

void move(WbNodeRef object, double *p0, double *p, double velocity)
{
    WbFieldRef object_translation = wb_supervisor_node_get_field(object, "translation");
    double pos[3] = {p0[0], p0[1], p0[2]};
    double k = 0.001;

    while (wb_robot_step(TIME_STEP) != -1) 
    {
        if (pos[0] < p[0])
        {
            pos[0] += (k*velocity);
        } else
        {
            pos[0] -= (k*velocity);
        }
        /*if (pos[1] < p[1])
        {
            pos[1] += (k*velocity);
        } else
        {
            pos[1] -= (k*velocity);
        }*/
        if (pos[2] < p[2])
        {
            pos[2] += (k*velocity);
        } else
        {
            pos[2] -= (k*velocity);
        }

        wb_supervisor_field_set_sf_vec3f(object_translation, pos);

        if((pos[0]-p[0] < k) && (pos[1]-p[1] < k) && (pos[2]-p[2] < k))
        {
          break;           
        }

        if((pos[0]-p[0] < (k*velocity)) && (pos[1]-p[1] < (k*velocity)) && (pos[2]-p[2] < (k*velocity)))
        {
          velocity--;            
        }  
    }        
}

int main()
{
    wb_robot_init();

    WbDeviceTag ds1 = wb_robot_get_device("ds1");
    WbDeviceTag ds2 = wb_robot_get_device("ds2");
    wb_distance_sensor_enable(ds1, TIME_STEP);
    wb_distance_sensor_enable(ds2, TIME_STEP);
    double posin[3] = {0.159, 0, -0.106};
    double posfin[3] = {-0.125, 0, 0.178};    
    WbNodeRef block = wb_supervisor_node_get_from_def("Moving_Block");    
    WbFieldRef red_robot = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Vermelho"), "translation");
    WbFieldRef green_robot = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Verde"), "translation");
    WbFieldRef red_pointer = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Red_Pointer"), "translation");
    WbFieldRef green_pointer = wb_supervisor_node_get_field(wb_supervisor_node_get_from_def("Green_Pointer"), "translation");
    double l1, l2;
    double  *red_pos, *green_pos;
    double alt = 0.4;
    int controle=1;
    bool check = true;

    while (wb_robot_step(TIME_STEP) != -1) 
    {
        if(check == true)
        {
            l1 = wb_distance_sensor_get_value(ds1);
            l2 = wb_distance_sensor_get_value(ds2);
            if((l1 != 1000) || (l2 != 1000))
            {
                move(block, posin, posfin, 10.0);
                check = false;
            } 
        }     
        red_pos = wb_supervisor_field_get_sf_vec3f(red_robot);
        red_pos[1] += alt;
        wb_supervisor_field_set_sf_vec3f(red_pointer, red_pos);
        green_pos = wb_supervisor_field_get_sf_vec3f(green_robot);
        green_pos[1] += alt;
        wb_supervisor_field_set_sf_vec3f(green_pointer, green_pos);
        if(controle == 1)
        {
            alt -= 0.003;
        }else
        {
            alt += 0.003;
        }
        if((controle == 1) && (alt <= 0.2))
        {
            controle = 2;
        }
        if((controle == 2) && (alt >= 0.4))
        {
            controle = 1;
        }
        
    }

    wb_robot_cleanup();

    return 0;
}

